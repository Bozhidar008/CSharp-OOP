﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IPhone
    {
        public abstract void MakeACall(int number);
        
    }
}
